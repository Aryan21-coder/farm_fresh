from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
path('index/',views.index_view,name="index"),
 path('about/', views.about_view, name='about'),
path("contact/",views.contact_view,name="contact"),
path("shop/",views.shop_view,name="shop"),
path("cart/",views.cart_view,name="cart"),
path("dashboard-user/",views.dashboard_user_view,name="dashboard-user"),
path("dashboard-farmer/",views.dashboard_farmer_view,name="dashboard-farmer"),
path("my-products/",views.my_products_view,name="my-products"),
path("dashboard-farmer-profile/",views.dashboard_farmer_profile_view,name="dashboard-farmer-profile"),
path("dashboard-farmer-orders/",views.dashboard_farmer_orders_view,name="dashboard-farmer-orders"),
path('login/',views.login_view,name="login"),
path("register-farmer/",views.register_farmer_view,name="register_farmer"),

path("login-farmer/",views.login_farmer_view,name="login_farmer"),
]




