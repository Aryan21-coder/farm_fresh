from django.shortcuts import render,HttpResponse

# Create your views here.
def index_view(request):
    return render(request,'index.html')
   # return HttpResponse("this is first page")


def about_view(request):
    return render(request, 'about.html')

 
# Create your views here.
def contact_view(request):
    return render(request,'contact.html')

def shop_view(request):
    return render(request,'shop.html')

def cart_view(request):
    return render(request,'cart.html')
    
def dashboard_user_view(request):
    return render(request,'dashboard-user.html')
    
def dashboard_farmer_view(request):
    return render(request,'dashboard-user.html')
    
def my_products_view(request):
    return render(request,'my-products')

def dashboard_farmer_profile_view(request):
    return render(request,'dashboard-farmer-profile') 
    
def dashboard_farmer_orders_view(request):
    return render(request,'dashboard-farmer-orders') 
 
def login_view(request):
    return render(request,'login.html')
     
         
def register_farmer_view(request):
    return render(request,'register-farmer.html')

def login_farmer_view(request):
    return render(request,'login-farmer.html')


